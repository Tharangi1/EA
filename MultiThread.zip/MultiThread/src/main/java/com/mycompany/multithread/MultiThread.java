/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.multithread;

/**
 *
 * @author WAY PRATHIRANGA
 */
public class MultiThread {

    public static void main(String[] args) {
     
    }
}
