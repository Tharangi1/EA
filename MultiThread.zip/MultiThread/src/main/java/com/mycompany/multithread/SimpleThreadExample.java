/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.multithread;

/**
 *
 * @author WAY PRATHIRANGA
 */
public class SimpleThreadExample extends Thread {
    @Override
    public void run() {
        System.out.println(Thread.currentThread().getId() + " - Thread is Running...");
    }

    public static void main(String[] args) {
        SimpleThreadExample thread1 = new SimpleThreadExample();
        SimpleThreadExample thread2 = new SimpleThreadExample();

        thread1.start();
        thread2.start();
    }
}

