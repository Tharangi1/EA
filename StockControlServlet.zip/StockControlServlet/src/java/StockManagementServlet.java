import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.*;

@WebServlet(urlPatterns = {"/StockManagementServlet"})
public class StockManagementServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("username") == null) {
            response.sendRedirect("login");
            return;
        }

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Stock Management</title>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");

        // Embedded CSS for styling
        out.println("<style>");
        out.println("body { font-family: Arial, sans-serif; background-color: #f4f6f8; margin: 0; padding: 20px; }");
        out.println("h2 { color: #2c3e50; }");
        out.println("table { width: 100%; border-collapse: collapse; margin-top: 20px; background-color: #fff; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }");
        out.println("th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #ddd; }");
        out.println("th { background-color: #34495e; color: white; }");
        out.println("tr:hover { background-color: #f1f1f1; }");
        out.println("a { text-decoration: none; color: #3498db; }");
        out.println("a:hover { text-decoration: underline; }");
        out.println(".actions { white-space: nowrap; }");
        out.println("</style>");

        out.println("</head>");
        out.println("<body>");
        out.println("<h2>Stock List</h2>");

        try (Connection conn = DatabaseUtil.getConnection()) {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM stock");

            out.println("<table>");
            out.println("<tr><th>Product Name</th><th>Quantity</th><th>Price</th><th class='actions'>Actions</th></tr>");

            while (rs.next()) {
                String productName = rs.getString("product_name");
                int quantity = rs.getInt("quantity");
                double price = rs.getDouble("price");

                out.println("<tr>");
                out.println("<td>" + productName + "</td>");
                out.println("<td>" + quantity + "</td>");
                out.println("<td>$" + String.format("%.2f", price) + "</td>");
                out.println("<td class='actions'>"
                        + "<a href='updateStock?id=" + rs.getInt("id") + "'>Update</a> | "
                        + "<a href='deleteStock?id=" + rs.getInt("id") + "'>Delete</a></td>");
                out.println("</tr>");
            }
            out.println("</table>");
        } catch (SQLException e) {
            e.printStackTrace();
            out.println("<p style='color:red;'>Database error occurred.</p>");
        }

        out.println("</body>");
        out.println("</html>");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Stock Management Servlet";
    }
}
