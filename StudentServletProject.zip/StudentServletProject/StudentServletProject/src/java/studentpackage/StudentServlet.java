package studentpackage;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class StudentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String id = request.getParameter("id");
        String name = request.getParameter("name");
        String course = request.getParameter("course");

        Connection con = null;
        PreparedStatement ps = null;
        
        try {
            Class.forName("com.mysql.jdbc.Driver"); // Changed to older driver for Java 7
            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/studentdb", "root", "");
            ps = con.prepareStatement(
                "INSERT INTO student VALUES (?, ?, ?)");
            ps.setInt(1, Integer.parseInt(id));
            ps.setString(2, name);
            ps.setString(3, course);
            ps.executeUpdate();

            out.println("<h3>Student Record Inserted Successfully!</h3>");
            out.println("<a href='index.html'>Back to Form</a>");
        } catch (Exception e) {
            out.println("<h3>Error: " + e.getMessage() + "</h3>");
        } finally {
            try { if (ps != null) ps.close(); } catch (SQLException e) {}
            try { if (con != null) con.close(); } catch (SQLException e) {}
        }
    }
}